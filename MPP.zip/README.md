P3. Movie rental</br>
A movie rental shop manages information about ​movies ​and ​clients.</br>
Create an application which allows to:</br>
­perform CRUD operations on ​movies​ and ​clients­rent​ movies</br>
­filter entities based on various criteria</br>
­reports: e.g. find the most rented movie
