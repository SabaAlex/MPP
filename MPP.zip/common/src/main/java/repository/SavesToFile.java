package repository;

public interface SavesToFile {
    void saveToFile();
}
